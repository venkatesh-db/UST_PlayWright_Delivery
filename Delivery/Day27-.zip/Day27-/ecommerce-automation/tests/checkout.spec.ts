
import { test, expect } from '@playwright/test';
import { ProductPage } from '../pages/ProductPage';
import { CheckoutPage } from '../pages/CheckoutPage';
import { HomePage } from '../pages/HomePage';

test.describe('Checkout Flow', () => {
  let homePage: HomePage;
  let productPage: ProductPage;
  let checkoutPage: CheckoutPage;

  test.beforeEach(async ({ page }) => {
    homePage = new HomePage(page);
    productPage = new ProductPage(page);
    checkoutPage = new CheckoutPage(page);
    await page.goto('/');
  });

  test('Place order successfully', async ({ page }) => {
    // Search & add product to cart
    await homePage.searchProduct('Laptop');
    await homePage.selectProduct(0);
    await productPage.addToCart();
    await productPage.goToCart();

    // Fill checkout details
    await checkoutPage.fillCheckoutDetails('John Doe', '123 Main St', '4111111111111111');
    await checkoutPage.placeOrder();

    const successMessage = await checkoutPage.getSuccessMessage();
    expect(successMessage).toContain('Order placed successfully');
  });
});
