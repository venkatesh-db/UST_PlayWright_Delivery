
import { test, expect } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';

test.describe('Login Tests', () => {
  let loginPage: LoginPage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    await loginPage.navigate();
  });

  test('Successful login with valid credentials', async ({ page }) => {
    await loginPage.login('validUser', 'validPassword');
    // Expect URL to change or user to see homepage
    await expect(page).toHaveURL(/home/);
  });

  test('Login fails with invalid credentials', async () => {
    await loginPage.login('invalidUser', 'wrongPassword');
    const error = await loginPage.getErrorMessage();
    expect(error).toContain('Invalid username or password');
  });
});
