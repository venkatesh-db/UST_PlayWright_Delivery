

import { test, expect } from '@playwright/test';
import { HomePage } from '../pages/HomePage';
import { ProductPage } from '../pages/ProductPage';

test.describe('Search and Add to Cart', () => {
  let homePage: HomePage;
  let productPage: ProductPage;

  test.beforeEach(async ({ page }) => {
    homePage = new HomePage(page);
    productPage = new ProductPage(page);
    await page.goto('/'); // Go to homepage
  });

  test('Search for a product and add to cart', async ({ page }) => {
    await homePage.searchProduct('Laptop');
    await homePage.selectProduct(0); // select first product
    await productPage.addToCart();

    // Verify cart icon shows 1 item
    const cartCount = await page.locator('#cartCount').textContent();
    expect(cartCount).toBe('1');
  });
});
