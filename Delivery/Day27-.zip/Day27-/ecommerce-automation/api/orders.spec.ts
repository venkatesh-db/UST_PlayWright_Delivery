
import { test, expect } from '@playwright/test';

const baseURL = 'http://localhost:3000/api'; // replace with your actual API URL
let orderId: string;

test.describe('Orders API Tests', () => {

  test('Create a new order', async ({ request }) => {
    const response = await request.post(`${baseURL}/orders`, {
      data: {
        productId: '123',
        quantity: 1,
        customerName: 'John Doe',
        address: '123 Main St',
        paymentMethod: 'card'
      }
    });

    expect(response.status()).toBe(201); // Created
    const body = await response.json();
    expect(body).toHaveProperty('id');
    orderId = body.id;
  });

  test('Get the created order', async ({ request }) => {
    const response = await request.get(`${baseURL}/orders/${orderId}`);
    expect(response.status()).toBe(200);

    const body = await response.json();
    expect(body.id).toBe(orderId);
    expect(body.customerName).toBe('John Doe');
    expect(body.address).toBe('123 Main St');
  });

  test('Fail to get a non-existing order', async ({ request }) => {
    const response = await request.get(`${baseURL}/orders/invalid-id`);
    expect(response.status()).toBe(404);
  });

});
