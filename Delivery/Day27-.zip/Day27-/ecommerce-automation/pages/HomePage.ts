
import { Page } from '@playwright/test';

export class HomePage {
  constructor(private page: Page) {}

  private searchBox = '#search';
  private searchButton = '#searchBtn';
  private productLink = '.product-item';

  async searchProduct(productName: string) {
    await this.page.fill(this.searchBox, productName);
    await this.page.click(this.searchButton);
  }

  async selectProduct(index: number = 0) {
    await this.page.locator(this.productLink).nth(index).click();
  }
}
