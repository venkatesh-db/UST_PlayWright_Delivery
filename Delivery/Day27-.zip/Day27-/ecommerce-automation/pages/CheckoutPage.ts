

import { Page } from '@playwright/test';

export class CheckoutPage {
  constructor(private page: Page) {}

  private checkoutButton = '#checkoutBtn';
  private nameInput = '#name';
  private addressInput = '#address';
  private paymentInput = '#payment';
  private placeOrderButton = '#placeOrderBtn';
  private orderSuccessMessage = '.success-message';

  async fillCheckoutDetails(name: string, address: string, payment: string) {
    await this.page.fill(this.nameInput, name);
    await this.page.fill(this.addressInput, address);
    await this.page.fill(this.paymentInput, payment);
  }

  async placeOrder() {
    await this.page.click(this.placeOrderButton);
  }

  async getSuccessMessage() {
    return this.page.textContent(this.orderSuccessMessage);
  }
}
