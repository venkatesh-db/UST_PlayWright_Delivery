
import { Page } from '@playwright/test';

export class ProductPage {
  constructor(private page: Page) {}

  private addToCartButton = '#addToCartBtn';
  private cartIcon = '#cart';

  async addToCart() {
    await this.page.click(this.addToCartButton);
  }

  async goToCart() {
    await this.page.click(this.cartIcon);
  }
}
