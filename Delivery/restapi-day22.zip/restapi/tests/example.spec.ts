

import { test, expect, chromium } from '@playwright/test';

test.describe('JSONPlaceholder API CRUD', () => {
  let postId: number;

  // ---------------- GET ----------------
  test('GET /posts/100', async ({ request }) => {
    const response = await request.get('https://jsonplaceholder.typicode.com/posts/100');
    expect(response.status()).toBe(200);

    const data = await response.json();
    console.log('✅ GET /posts/100 Response:', data);
  });

  // ---------------- POST ----------------
  test('POST /posts - create new post', async ({ request }) => {
    const payload = { title: 'foo', body: 'bar', userId: 1 };

    const response = await request.post('https://jsonplaceholder.typicode.com/posts', {
      headers: { 'Content-Type': 'application/json' },
      data: payload,
    });

    expect(response.status()).toBe(201);

    const data = await response.json();
    console.log('✅ POST /posts Response:', data);

    postId = data.id; // Save ID for PUT/DELETE
    console.log('🆔 Created Post ID:', postId);
  });

  // ---------------- PUT ----------------
  test('PUT /posts/:id - update post (with login & video recording)', async ({ request }) => {
    // Launch browser for login + video recording
    const browser = await chromium.launch();
    const context = await browser.newContext({
      recordVideo: { dir: 'videos/', size: { width: 1280, height: 720 } },
    });

    const page = await context.newPage();
    await page.goto('https://practice.expandtesting.com/login');

    // Perform login (UI)
    await page.fill('#username', 'practice');
    await page.fill('#password', 'SuperSecretPassword!');
    await page.click('button[type="submit"]');

    // ✅ Verify login success by checking the URL (fix for .flash.success)
    await expect(page).toHaveURL('https://practice.expandtesting.com/secure', { timeout: 7000 });

    console.log('✅ Login successful, recording video...');

    // Prepare PUT request payload
    const payload = { title: 'updated title', body: 'updated body', userId: 101 };

    // Send PUT request
    const response = await request.put(
      `https://jsonplaceholder.typicode.com/posts/${postId || 1}`,
      {
        headers: { 'Content-Type': 'application/json' },
        data: payload,
      }
    );

    console.log('✅ PUT Response Status:', response.status());
    expect(response.status()).toBe(200);

    const data = await response.json();
    console.log('✅ PUT Response Body:', data);

    // Close video context
    await context.close();
    await browser.close();
  });

  // ---------------- DELETE ----------------
  test('DELETE /posts/:id', async ({ request }) => {
    const response = await request.delete(
      `https://jsonplaceholder.typicode.com/posts/${postId || 1}`
    );

    console.log('✅ DELETE Response Status:', response.status());
    expect(response.status()).toBe(200);
  });
});
