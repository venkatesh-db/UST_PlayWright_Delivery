

import { test, expect, request, APIRequestContext } from '@playwright/test';

let apiContext: APIRequestContext;
let token: string;
let userId: number;

test.describe('🔥 Full API CRUD with Auth & JSON Payloads', () => {

  test.beforeAll(async () => {
    console.log('🔐 Logging in to get token...');

    // ✅ Create a temporary request context just for auth
    const tempContext = await request.newContext();

    const authResponse = await tempContext.post('https://reqres.in/api/login', {
      headers: { 'Content-Type': 'application/json' },
      data: {
        email: 'eve.holt@reqres.in',
        password: 'cityslicka'
      }
    });

    console.log('Auth Status:', authResponse.status());
    const authData = await authResponse.json();
    console.log('Auth Body:', authData);

    expect(authResponse.status()).toBe(200); // should pass
    token = authData.token;
    console.log('✅ Token:', token);

    // ✅ Create reusable API context with token for CRUD
    apiContext = await request.newContext({
      baseURL: 'https://reqres.in/api',
      extraHTTPHeaders: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });

    await tempContext.dispose();
  });

  // ---------------- CREATE ----------------
  test('POST /users - Create a new user', async () => {
    const payload = { name: 'Venkatesh', job: 'QA Engineer' };
    const response = await apiContext.post('/users', { data: payload });
    expect(response.status()).toBe(201);

    const data = await response.json();
    userId = data.id;
    console.log('✅ Created user:', data);
  });

  // ---------------- READ ----------------
  test('GET /users/:id - Fetch created user', async () => {
    const response = await apiContext.get(`/users/${userId}`);
    expect(response.status()).toBe(200);

    const data = await response.json();
    console.log('📘 User data:', data);
  });

  // ---------------- UPDATE ----------------
  test('PUT /users/:id - Update user', async () => {
    const payload = { name: 'Venkatesh Updated', job: 'Senior QA Engineer' };
    const response = await apiContext.put(`/users/${userId}`, { data: payload });
    expect(response.status()).toBe(200);

    const data = await response.json();
    console.log('✏️ Updated user:', data);
  });

  // ---------------- DELETE ----------------
  test('DELETE /users/:id - Delete user', async () => {
    const response = await apiContext.delete(`/users/${userId}`);
    expect(response.status()).toBe(204);
    console.log('🗑️ Deleted user successfully!');
  });

});
