

import { test, expect } from '@playwright/test';
import { request } from '@playwright/test';

test('POST /posts - Create a new post', async ({ page,request }) => {


  const payload = {
    title: 'foo',
    body: 'bar',
    userId: 1
  };

  const response = await request.post('https://jsonplaceholder.typicode.com/posts', {
    headers: {
      'Content-Type': 'application/json'
    },
    data: payload
  });

  await page.screenshot({path: 'example.png',fullPage: true});

  console.log('Response Status:', response.status());
  console.log('Response Body:', await response.json());

  expect(response.status()).toBe(201);
});


test ('Post api-venkatesh ',async ({})=>{


  const response={
     userId: 100,
    title: "all ust smiles",
    body: "23 great coders"

  }


   const reply=await request.newContext({

    baseURL: 'https://jsonplaceholder.typicode.com/',
    extraHTTPHeaders:{
  'Content-Type': 'application/json',
    }

   })
   
   const resp= await reply.post('/posts' , {
data:response
});

  console.log('Post api-venkatesh Response Status:', resp.status());
  console.log('Post api-venkatesh Response Body:', await resp.json());


   expect(resp.status()).toBe(201);




})



test('dog image', async ({  }) => {



    const reply=await request.newContext({

    baseURL: 'https://dog.ceo',
  
   })
   
   const resp=  await reply.get('/api/breeds/image/random' );

   expect(resp.status()).toBe(200);

});
