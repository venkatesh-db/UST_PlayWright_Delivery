

import { test, expect } from '@playwright/test';
import { promises as fs } from 'fs';
import path from 'path';

const VIEWPORT = { width: 1280, height: 720 };
const RECORDINGS_DIR = path.join(process.cwd(), 'recordings');
const FINAL_VIDEOS_DIR = path.join(process.cwd(), 'videos');
const SCREENSHOTS_DIR = path.join(process.cwd(), 'artifacts', 'screenshots');
const tsNow = () => new Date().toISOString().replace(/[:.]/g, '-');

test('Day 16 — Screenshots, Video, Viewport (Playwright TS) FINAL', async ({ browser }, testInfo) => {
  await fs.mkdir(RECORDINGS_DIR, { recursive: true });
  await fs.mkdir(FINAL_VIDEOS_DIR, { recursive: true });
  await fs.mkdir(SCREENSHOTS_DIR, { recursive: true });

  const context = await browser.newContext({
    viewport: VIEWPORT,
    recordVideo: { dir: RECORDINGS_DIR, size: VIEWPORT }
  });

  const page = await context.newPage();

  // 1) Navigate -> viewport screenshot
  await page.goto('https://www.wikipedia.org/');
  const shot1 = path.join(SCREENSHOTS_DIR, `wikipedia_home_${tsNow()}.png`);
  await page.screenshot({ path: shot1, fullPage: false });
  console.log('Saved screenshot (viewport):', shot1);

  // 2) Interact + full-page screenshot
  await page.fill('input#searchInput', 'Playwright');
  await Promise.all([
    page.waitForNavigation({ waitUntil: 'load' }),
    page.press('input#searchInput', 'Enter')
  ]);
  await page.waitForLoadState('networkidle');

  const shot2 = path.join(SCREENSHOTS_DIR, `search_result_${tsNow()}.png`);
  await page.screenshot({ path: shot2, fullPage: true });
  console.log('Saved screenshot (fullPage):', shot2);

  // 3) Element screenshot (optional)
  const content = await page.$('div#mw-content-text');
  if (content) {
    const shot3 = path.join(SCREENSHOTS_DIR, `content_area_${tsNow()}.png`);
    await content.screenshot({ path: shot3 });
    console.log('Saved element screenshot:', shot3);
  }

  // 4) Simple assertion BEFORE closing context
  const title = await page.title();
  expect(title.toLowerCase()).toContain('wikipedia');

  // Wait a little to capture motion in the video
  await page.waitForTimeout(1500);

  // 5) Close context to finalize video
  await context.close();

  // 6) Move the generated Playwright video to friendly location
  const video = page.video();
  if (video) {
    const generatedPath = await video.path();
    const finalVideoName = `day16_run_${tsNow()}.webm`;
    const finalVideoPath = path.join(FINAL_VIDEOS_DIR, finalVideoName);
    await fs.rename(generatedPath, finalVideoPath);
    console.log('🎬 Video moved to:', finalVideoPath);

    try {
      await testInfo.attach('run-video', { path: finalVideoPath, contentType: 'video/webm' });
    } catch (e) {
      console.warn('Could not attach video to testInfo:', (e as Error).message);
    }
  }

  // Attach screenshots to the report (optional)
  try {
    await testInfo.attach('screenshot-home', { path: shot1, contentType: 'image/png' });
    await testInfo.attach('screenshot-result', { path: shot2, contentType: 'image/png' });
  } catch {}

  console.log('Screenshots directory:', SCREENSHOTS_DIR);
  console.log('Final videos directory:', FINAL_VIDEOS_DIR);
});