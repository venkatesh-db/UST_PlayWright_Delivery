import { test, expect } from '@playwright/test';
import { LoginPage } from '../pages/loginPage';
import { DashboardPage } from '../pages/dashboardPage';



test('use can login acess', async ({ page }) => {


     const loginpage= new LoginPage(page)

     const dashboardPage = new DashboardPage(page)

     await loginpage.open('https://practice.expandtesting.com/login');

     await page.screenshot({path: 'fullpage.png',fullPage:true})

     await loginpage.login('practice','SuperSecretPassword!');

     await dashboardPage.verifyLoginSuccess();


  /*

  await page.goto('https://playwright.dev/');

  // Expect a title "to contain" a substring.
  await expect(page).toHaveTitle(/Playwright/);
 
  */


});
