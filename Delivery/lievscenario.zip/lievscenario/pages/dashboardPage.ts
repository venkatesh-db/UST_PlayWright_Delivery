
import { Page, expect } from "@playwright/test";
import { BasePage } from "./basePage";

export class DashboardPage extends BasePage {

    private successMessageSelector = "#flash";

    constructor(page: Page) {
        super(page);
    }

    async verifyLoginSuccess() {

        const successMessage = this.page.locator(this.successMessageSelector);
        await successMessage.screenshot({path: 'logo.png'});

        await expect(successMessage).toContainText("You logged into a secure area!");
    }

    async navigateToProfile() {
        await this.page.click('a[href="/profile"]');
    }
}
