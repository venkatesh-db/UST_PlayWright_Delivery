
import {Page } from "@playwright/test"
import { BasePage } from "./basePage";


export class LoginPage extends BasePage{


   // <input id ="username" type ="text"/>
     private usernameInput = '#username';
     private passwordinput= "#password";
     private loginButton='button[type="submit"]';

     constructor(page:Page){
        super(page)
     }

     async login(username: string , password: string ){

        await this.page.fill(this.usernameInput,username);
        await this.page.fill(this.passwordinput,password);
        await this.page.click(this.loginButton);

     }

}