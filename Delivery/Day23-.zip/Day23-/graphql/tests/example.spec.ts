

import { test, expect } from '@playwright/test';

const GRAPHQL_ENDPOINT = 'https://countries.trevorblades.com/';

test.describe('GraphQL API Demo', () => {

  // ---------------- QUERY ----------------
  test('Fetch country details using GraphQL query', async ({ request }) => {
    const query = `
      query GetCountry($code: ID!) {
        country(code: $code) {
          name
          capital
          currency
          continent {
            name
          }
        }
      }
    `;

    const variables = { code: "IN" };

    const response = await request.post(GRAPHQL_ENDPOINT, {
      headers: { 'Content-Type': 'application/json' },
      data: { query, variables }
    });

    expect(response.status()).toBe(200);

    const data = await response.json();
    console.log('GraphQL Query Response:', data);

    // Validate payload
    expect(data.data.country.name).toBe('India');
    expect(data.data.country.capital).toBe('New Delhi');
  });

  // ---------------- MUTATION ----------------
  // Note: Countries API is read-only, so mutation is just for demo structure
  test('Demo mutation structure', async ({ request }) => {
    const mutation = `
      mutation AddSample($input: String!) {
        addSample(input: $input) {
          result
        }
      }
    `;

    const variables = { input: "Hello GraphQL" };

    // Since this endpoint doesn't support mutation, this is just a demo POST
    const response = await request.post(GRAPHQL_ENDPOINT, {
      headers: { 'Content-Type': 'application/json' },
      data: { query: mutation, variables }
    });

    console.log('Mutation Response (expected error):', await response.json());
  });

});
