
import { test, expect } from '@playwright/test';
import { users } from '../fixtures/testData';

test.describe('Network Interception & Deep Equality Demo', () => {

  test('Intercept API request and validate response', async ({ page }) => {
    // Absolute URL to fetch
    const apiUrl = 'https://mockapi.local/api/users';

    // 1️⃣ Intercept the absolute URL
    await page.route(apiUrl, async route => {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({ users }),
      });
    });

    // 2️⃣ Set simple HTML content
    await page.setContent(`<html><body><pre id="response"></pre></body></html>`);

    // 3️⃣ Trigger fetch using the absolute URL
    await page.evaluate(async (url) => {
      const res = await fetch(url);
      const data = await res.json();
      document.querySelector('#response')!.textContent = JSON.stringify(data);
    }, apiUrl); // pass URL as argument

    // 4️⃣ Wait until #response has content
    const responseLocator = page.locator('#response');
    await expect(responseLocator).not.toHaveText(''); // waits until populated

    // 5️⃣ Parse content and validate
    const content = await responseLocator.textContent();
    const jsonResponse = JSON.parse(content || '{}');

    // 6️⃣ Deep equality check
    expect(jsonResponse).toEqual({ users });
  });

  // Parameterized tests with fixtures
  for (const user of users) {
    test(`Validate user role for ${user.name}`, async () => {
      const apiResponse = { id: user.id, name: user.name, role: user.role };
      expect(apiResponse).toEqual(user);
      expect(apiResponse.role).toMatch(/Admin|User|Guest/);
    });
  }
});
