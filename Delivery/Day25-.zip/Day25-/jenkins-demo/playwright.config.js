
// playwright.config.js
module.exports = {
  reporter: [['list'], ['html']],
  use: { headless: true }
};
