const { test, expect } = require('@playwright/test');

test('AI generated: check example.com title (auto-generated)', async ({ page }) => {
  await page.goto('https://example.com');
  await expect(page.locator('h1')).toHaveText('Example Domain');
});