

// mcp-server/generator-server.js
const express = require('express');
const app = express();
app.use(express.json());

app.post('/generate', (req, res) => {
  const prompt = (req.body.prompt || 'check example domain').replace(/"/g, '\\"');
  const code = `const { test, expect } = require('@playwright/test');

test('AI generated: ${prompt}', async ({ page }) => {
  await page.goto('https://example.com');
  await expect(page.locator('h1')).toHaveText('Example Domain');
});`;
  res.json({ code });
});

const port = process.env.PORT || 3001;
app.listen(port, () => console.log('Generator server running on http://localhost:' + port));
