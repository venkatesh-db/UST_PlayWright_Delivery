

// scripts/fetch-generated-tests.js
const fs = require('fs');

(async () => {
  const url = process.env.GENERATOR_URL || 'http://localhost:3001/generate';
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ prompt: 'check example.com title (auto-generated)' })
  });
  const json = await res.json();
  const code = json.code || '// no code returned';
  fs.writeFileSync('tests/generated.spec.js', code, 'utf8');
  console.log('Wrote tests/generated.spec.js');
})();
