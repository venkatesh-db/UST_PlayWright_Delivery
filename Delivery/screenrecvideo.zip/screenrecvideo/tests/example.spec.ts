

import { test, expect } from '@playwright/test';

// ---------------------------
// 1. Config Viewport
// ---------------------------
test.use({
  viewport: { width: 1280, height: 720 },   // Set viewport size
  video: { mode: 'on', size: { width: 1280, height: 720 } }, // enable video recording
  screenshot: 'on'  // automatically capture on failure
});

test('Day 16 - Screenshots, Video, Viewport Demo', async ({ page }) => {
  // Open a demo site
  await page.goto('https://www.wikipedia.org/');

  // ---------------------------
  // 2. Capture Screenshot (LIVE)
  // ---------------------------
  await page.screenshot({ path: 'wikipedia_home.png', fullPage: true });
  console.log('📸 Screenshot saved: wikipedia_home.png');

  // Example interaction
  await page.fill('input#searchInput', 'Playwright');
  await page.press('input#searchInput', 'Enter');

  // Wait for result
  await page.waitForTimeout(2000);
  await page.screenshot({ path: 'search_result.png', fullPage: true });
  console.log('📸 Screenshot saved: search_result.png');

  // ---------------------------
  // 3. Record Run (LIVE Video)
  // ---------------------------
  // Playwright automatically records video when "video" option is enabled in test.use()
  // Video is saved after the test ends
});
