
import { Page, expect } from '@playwright/test';

/**
 * Page Object: Dashboard Page
 * Encapsulates actions & verifications after login
 */
export class DashboardPage {
  readonly page: Page;

  constructor(page: Page) {
    this.page = page;
  }

  async assertLoggedIn() {
    await expect(this.page).toHaveURL(/logged-in-successfully/);
    await expect(this.page.locator('h1')).toContainText('Logged In Successfully');
  }
}
