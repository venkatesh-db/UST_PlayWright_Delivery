
import { Page, expect } from '@playwright/test';

/**
 * Page Object: Login Page
 * Encapsulates locators & actions for login screen
 */
export class LoginPage {
  readonly page: Page;
  readonly usernameInput = '#username';
  readonly passwordInput = '#password';
  readonly submitButton = '#submit';
  readonly errorMessage = '#error';

  constructor(page: Page) {
    this.page = page;
  }

  async goto() {
    await this.page.goto('https://practicetestautomation.com/practice-test-login/', {
      waitUntil: 'networkidle'
    });
  }

  async login(username: string, password: string) {
    await this.page.fill(this.usernameInput, username);
    await this.page.fill(this.passwordInput, password);
    await this.page.click(this.submitButton);
  }

  async assertErrorMessage(expected: string) {
    await expect(this.page.locator(this.errorMessage)).toHaveText(expected);
  }
}
