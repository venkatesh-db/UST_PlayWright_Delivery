
/**
 * Playwright Test with Page Objects
 * - Page classes encapsulate locators & actions
 * - Tests stay clean & expressive
 * - Fully interactive against real website
 *
 * Run: npx playwright test
 * 
 * npx playwright test --ui

npx playwright test tests/login.spec.ts


 */

import { test } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { DashboardPage } from '../pages/DashboardPage';

test.describe('Login Tests (Page Object Model)', () => {
  test('🟢 Successful login', async ({ page }) => {
    const loginPage = new LoginPage(page);
    const dashboard = new DashboardPage(page);

    await loginPage.goto();
    await loginPage.login('student', 'Password123');
    await dashboard.assertLoggedIn();
  });

  test('🔴 Invalid username shows error', async ({ page }) => {
    const loginPage = new LoginPage(page);

    await loginPage.goto();
    await loginPage.login('wrongUser', 'Password123');
    await loginPage.assertErrorMessage('Your username is invalid!');
  });

  test('🔴 Invalid password shows error', async ({ page }) => {
    const loginPage = new LoginPage(page);

    await loginPage.goto();
    await loginPage.login('student', 'WrongPass');
    await loginPage.assertErrorMessage('Your password is invalid!');
  });
});
