import { test, expect, request, APIRequestContext } from '@playwright/test';
import * as countryVars from './fixtures/country-vars.json';

const BASE_URL = 'https://countries.trevorblades.com/';
let api: APIRequestContext;

test.describe('GraphQL API Testing', () => {
  test.beforeAll(async () => {
    api = await request.newContext({
      baseURL: BASE_URL,
      extraHTTPHeaders: { 'Content-Type': 'application/json' },
    });
  });

  test.afterAll(async () => {
    await api.dispose();
  });

  // 1️⃣ Query example
  test('Query: get country by code', async () => {
    const query = `
      query GetCountry($code: ID!) {
        country(code: $code) {
          code
          name
          continent {
            name
          }
          languages {
            name
          }
        }
      }
    `;

    const res = await api.post('', {
      data: { query, variables: countryVars }, // loads from fixtures/country-vars.json
    });

    expect(res.ok()).toBeTruthy();
    const body = await res.json();

    // validate deeply
    expect(body.data.country).toMatchObject({
      code: 'IN',
      name: 'India',
      continent: { name: 'Asia' },
    });
    expect(Array.isArray(body.data.country.languages)).toBe(true);
  });

  // 2️⃣ Parameterized test
  const codes = ['US', 'BR', 'JP'];
  for (const code of codes) {
    test(`Query: country ${code}`, async () => {
      const query = `
        query ($code: ID!) {
          country(code: $code) {
            code
            name
          }
        }
      `;
      const res = await api.post('', { data: { query, variables: { code } } });
      const body = await res.json();
      expect(body.data.country.code).toBe(code);
      expect(body.data.country.name).toBeTruthy();
    });
  }

  // 3️⃣ Mock Mutation test (since API doesn’t support mutations)
  test('Mock Mutation: createCountry (simulated)', async () => {
    const fakeMutation = `
      mutation CreateCountry($code: ID!, $name: String!) {
        createCountry(code: $code, name: $name) {
          code
          name
        }
      }
    `;

    // simulate server response
    const res = await api.fetch('', {
      method: 'POST',
      data: {
        query: fakeMutation,
        variables: { code: 'XX', name: 'Playland' },
      },
    });

    // Since endpoint doesn’t support, we simulate expected structure
    const fakeResponse = {
      data: { createCountry: { code: 'XX', name: 'Playland' } },
    };

    expect(fakeResponse.data.createCountry).toEqual({
      code: 'XX',
      name: 'Playland',
    });
  });
});
