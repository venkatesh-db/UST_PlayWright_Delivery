
import { test, expect } from '@playwright/test';

test('GraphQL query works via API', async ({ request }) => {
  const response = await request.post('https://countries.trevorblades.com/graphql', {
    data: {
      query: `
        query GetCountry($code: ID!) {
          country(code: $code) {
            code
            name
            continent { name }
          }
        }
      `,
      variables: { code: 'IN' },
    },
  });

  expect(response.status()).toBe(200);

  const json = await response.json();
  console.log('GraphQL API Response:', json);

  expect(json.data.country.name).toBe('India');
});
