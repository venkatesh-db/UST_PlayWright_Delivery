
import { test, expect } from '@playwright/test';

test.describe('JSONPlaceholder API CRUD', () => {
  let postId: number;

  // ---------------- GET ----------------
  test('GET /posts/1', async ({ request }) => {
    const response = await request.get('https://jsonplaceholder.typicode.com/posts/1');
    expect(response.status()).toBe(200);

    const data = await response.json();
    console.log('GET /posts/1:', data);
  });

  // ---------------- POST ----------------
  test('POST /posts - create new post', async ({ request }) => {
    const payload = { title: 'foo', body: 'bar', userId: 1 };

    const response = await request.post('https://jsonplaceholder.typicode.com/posts', {
      headers: { 'Content-Type': 'application/json' },
      data: payload
    });

    expect(response.status()).toBe(201);

    const data = await response.json();
    console.log('POST response:', data);

    postId = data.id; // save ID for PUT/DELETE
  });

  // ---------------- PUT ----------------
  test('PUT /posts/:id - update post', async ({ request }) => {
    if (!postId) test.skip();

    const payload = { id: postId, title: 'updated title', body: 'updated body', userId: 1 };
    const response = await request.put(`https://jsonplaceholder.typicode.com/posts/${postId}`, {
      headers: { 'Content-Type': 'application/json' },
      data: payload
    });

    expect(response.status()).toBe(200);

    const data = await response.json();
    console.log('PUT response:', data);
  });

  // ---------------- DELETE ----------------
  test('DELETE /posts/:id', async ({ request }) => {
    if (!postId) test.skip();

    const response = await request.delete(`https://jsonplaceholder.typicode.com/posts/${postId}`);
    expect(response.status()).toBe(200); // JSONPlaceholder returns 200 on delete
    console.log('DELETE status:', response.status());
  });
});
