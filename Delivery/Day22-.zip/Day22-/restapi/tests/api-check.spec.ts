

import { test, expect } from '@playwright/test';

test('POST /posts - Create a new post', async ({ request }) => {
  const payload = {
    title: 'foo',
    body: 'bar',
    userId: 1
  };

  const response = await request.post('https://jsonplaceholder.typicode.com/posts', {
    headers: {
      'Content-Type': 'application/json'
    },
    data: payload
  });

  console.log('Response Status:', response.status());
  console.log('Response Body:', await response.json());

  expect(response.status()).toBe(201);
});
