

/**
 * Playwright Example
 * Parallelism + Worker Isolation + Data-driven tests
 *
 * - Playwright runs tests in parallel workers by default
 * - Each worker is isolated: new browser context, clean state
 * - Data-driven tests load user data from JSON
 *
 * Run examples:
 *   npx playwright test --grep "@smoke"
 *   npx playwright test --grep "@regression"
 *


Playwright sees 3 tests:

@smoke login test for user: student

@regression login test for user: wrongUser

@regression login test for user: student

It distributes them across workers. Example (on 3 workers):

Worker 1 → runs smoke test

Worker 2 → runs regression test (wrong user)

Worker 3 → runs regression test (wrong password)

Each worker opens a fresh isolated browser context.

No cookies, no session leaks, no shared state.

Even though tests run in parallel, they don’t interfere.




# Run with 4 workers
npx playwright test --workers=4

# Force sequential (1 worker)
npx playwright test --workers=1

npx playwright test --workers=3


 */

import { test, expect } from '@playwright/test';
import users from '../data/users.json'; // JSON import

test.describe('PracticeTestAutomation Login Page', () => {
  
  const baseUrl = 'https://practicetestautomation.com/practice-test-login/';

  test.beforeEach(async ({ page }) => {
    await page.goto(baseUrl, { waitUntil: 'networkidle' });
  });

  // Dynamically create tests from JSON
  for (const user of users) {
    test(`🔹 ${user.tag} login test for user: ${user.username}`, async ({ page }) => {
      await page.fill('#username', user.username);
      await page.fill('#password', user.password);
      await page.click('#submit');

      if (user.expectedUrl) {
        await expect(page).toHaveURL(new RegExp(user.expectedUrl));
        await expect(page.locator('h1')).toContainText('Logged In Successfully');
      }

      if (user.expectedError) {
        await expect(page.locator('#error')).toHaveText(user.expectedError);
      }
    });
  }
});

