


// tests/login.spec.ts

import { test, expect, Page } from '@playwright/test';

test.describe('PracticeTestAutomation Login Page', () => {
  let baseUrl: string;

  test.beforeAll(async () => {
    console.log('🔧 beforeAll: initializing base URL');
    baseUrl = 'https://practicetestautomation.com/practice-test-login/';
    // (optional) you could do API or DB setup here
  });

  test.afterAll(async () => {
    console.log('🧹 afterAll: cleanup');
    // (optional) teardown logic if needed
  });

  test.beforeEach(async ({ page }) => {
    console.log('➡️ beforeEach: navigating to login page');
    try {
      await page.goto(baseUrl, { waitUntil: 'networkidle' });
    } catch (err) {
      console.error('❌ Error in beforeEach while navigating:', err);
      throw err;
    }
  });

  test.afterEach(async ({ page }) => {
    console.log('✅ afterEach: closing page (if open)');
    try {
      await page.close();
    } catch (err) {
      // In some cases the page might already be closed; ignore
      console.warn('⚠️ afterEach encountered error closing page:', err);
    }
  });

  test('should login successfully with valid credentials', async ({ page }) => {
    console.log('🏷️ Test: valid credentials login');
    await page.fill('#username', 'student');
    await page.fill('#password', 'Password123');
    await page.click('#submit');

    // expecting redirect / success page
    await expect(page).toHaveURL(/logged-in-successfully/);
    const successText = await page.locator('h1').textContent();
    expect(successText).toContain('Logged In Successfully');
  });

  test('should show error for invalid username', async ({ page }) => {
    console.log('🏷️ Test: invalid username');
    await page.fill('#username', 'wrongUser');
    await page.fill('#password', 'Password123');
    await page.click('#submit');

    const errorMsg = await page.locator('#error').textContent();
    expect(errorMsg).toBe('Your username is invalid!');
  });

  test('should show error for invalid password', async ({ page }) => {
    console.log('🏷️ Test: invalid password');
    await page.fill('#username', 'student');
    await page.fill('#password', 'WrongPass');
    await page.click('#submit');

    const errorMsg = await page.locator('#error').textContent();
    expect(errorMsg).toBe('Your password is invalid!');
  });
});
