

// tests/login.spec.ts
import { test, expect } from '@playwright/test';


// npx playwright test --grep "@smoke"  npx playwright test --grep "@regression"

 

test.describe('PracticeTestAutomation Login Page', () => {
  const baseUrl = 'https://practicetestautomation.com/practice-test-login/';

  test.beforeEach(async ({ page }) => {
    await page.goto(baseUrl, { waitUntil: 'networkidle' });
  });

  test('🟢 @smoke should login successfully with valid credentials', async ({ page }) => {
    await page.fill('#username', 'student');
    await page.fill('#password', 'Password123');
    await page.click('#submit');
    await expect(page).toHaveURL(/logged-in-successfully/);
    await expect(page.locator('h1')).toContainText('Logged In Successfully');
  });

  test('🔴 @regression should show error for invalid username', async ({ page }) => {
    await page.fill('#username', 'wrongUser');
    await page.fill('#password', 'Password123');
    await page.click('#submit');
    await expect(page.locator('#error')).toHaveText('Your username is invalid!');
  });

  test('🟡 @regression should show error for invalid password', async ({ page }) => {
    await page.fill('#username', 'student');
    await page.fill('#password', 'WrongPass');
    await page.click('#submit');
    await expect(page.locator('#error')).toHaveText('Your password is invalid!');
  });
});
